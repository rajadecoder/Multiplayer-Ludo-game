# Cordova Railway App
Railway app for peoples who are preparing for railway exams.App contains multiple choice questions covering all topics like Aptitude,Reasining,History and Mathematics.
</br>

</br>

#App Preview
</br>

![App Preview Home screen](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(29).png?alt=media&token=85f17426-0e61-4826-853d-1bcd818659eb)
</br>
</br>

![Menu](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(30).png?alt=media&token=4864662c-aa3f-4e76-b589-6e6685cec80a)
